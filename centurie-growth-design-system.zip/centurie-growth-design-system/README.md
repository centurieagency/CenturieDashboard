# Centurie Growth

Système de design extrait de centuriegrowth.com (CSS du site, variables `:root` et styles calculés). Service géré de croissance Instagram : un ton sobre, premium et humain, sur une palette crème, encre et taupe. Ce document donne les règles d'usage à suivre pour produire toute page, slide ou visuel Centurie Growth.

## Principes

1. **Carré et net.** Aucun arrondi sauf les boutons (`radius-sm`, 2px) et les avatars (`radius-full`). Pas d'ombres (`shadow-none`) : la profondeur vient des bordures 1px et des changements de fond.
2. **Crème d'abord.** Le fond par défaut est `cream`. On alterne avec `cream-alt` pour une section, `white` pour les cartes, et `ink` pour une seule section sombre par page (la FAQ sur le site).
3. **Deux voix typographiques.** Poppins (`display`) pour tout ce qui est titre, prix, nom ou numéro. Inter (`body`) pour le texte courant et l'UI. Alex Brush (`script`) n'apparaît que sur le mot « Growth » sous le logotype.
4. **Le taupe est une signature, pas une couleur de texte.** `taupe-dark` sert aux sur-titres (eyebrows), aux numéros d'étape et au focus. `taupe` sert d'accent sur `ink`. Jamais de paragraphe en taupe.
5. **Beaucoup d'air.** Sections de 80 à 120px de padding vertical, conteneur de 1180px, lignes de texte limitées à 46 à 58ch.

## Contenu et ton

- Langue du site : anglais. Phrases courtes, affirmatives, souvent en deux temps : « Attention isn't for sale. Growth is earned. We just run it for you. »
- On parle de résultats concrets (tables réservées, DM, commandes du week-end), jamais de « followers » comme fin en soi. La promesse centrale : « Followers were never the point. »
- Anti-promesses assumées : « No bots. No ads. No guesswork. » Honnêteté sur le risque (« No system can promise zero risk »).
- Le service est **géré par un humain** : insister sur « managed », « a person who knows your account », « not a login ».
- Titres de section en casse phrase (« How it works », « Three ways to work with us »). Sur-titres en MAJUSCULES espacées (`eyebrow`).
- Ponctuation classique. Pas de tiret long, pas d'emoji, pas de points d'exclamation.
- CTA : « Book a discovery call » (principal), « See how it works » (secondaire), « Talk to us » (cartes d'offre).

## Couleurs

| Rôle | Token | Usage |
| --- | --- | --- |
| Fond de page | `cream` | Toutes les sections par défaut |
| Fond alterné | `cream-alt` | Une section de grille (« What's included ») |
| Surface carte | `white` | Cartes d'offre et témoignages, avec `border` ou `border-strong` |
| Encre | `ink` | Bouton principal, section sombre, bordure de l'offre mise en avant, tag |
| Texte | `charcoal` | Titres et texte par défaut |
| Texte secondaire | `text-lead`, `text-body`, `text-secondary`, `text-muted` | Du plus fort au plus discret, voir chaque token |
| Accent | `taupe-dark` (clair), `taupe` (sur `ink`) | Sur-titres, numéros, signe « + » de la FAQ |

Contrastes signalés (valeurs du site conservées) : `taupe-dark` sur `cream` fait 3,4:1, à réserver aux libellés 13px+ en graisse 600 ; `text-subtle` fait 4,15:1, uniquement pour la ligne légale ; texte blanc sur disque `taupe` (avatars) fait 2,65:1, n'y mettre qu'une initiale.

## Typographie

Polices Google (pas de fichiers locaux) : Poppins 400 à 800, Inter 400 à 600, Alex Brush 400.

- H1 : `hero-title` (68px desktop, 38px mini, interlignage 1.05, approche -0.01em).
- Titre de section : `eyebrow` puis `section-title`.
- Paragraphe d'accroche : `lead` en `text-lead`.
- Boutons : `ui` (Inter 600, 14.5px).
- Prix : `price` en Poppins, suivi de « /mo » en Inter 14px 500 `text-muted`.

## Composants observés sur le site

Non livrés en code ici ; à reproduire avec ces valeurs exactes.

- **Bouton principal** : fond `ink`, texte `white`, bordure 1px `ink`, padding 12px 24px, `radius-sm`. Survol : fond #000 et translation -1px.
- **Bouton ghost** : transparent, texte `ink`, bordure 1px `border-control`. Survol : fond `ink`, texte `white`.
- **Bouton clair** (sur `ink`) : fond `white`, texte `ink`. Survol : `taupe-light`.
- **Carte d'offre** : fond `white`, bordure `border-strong`, padding 38px 32px, carrée. Version mise en avant : bordure `ink` et tag `MOST POPULAR` (`tag`, fond `ink`) posé 13px au-dessus du bord. Puces : la fleur de lys noire à 11px.
- **Carte témoignage** : fond `white`, bordure `border`, padding 32px 30px, avatar 40px `taupe` avec initiale.
- **Grille « inclus »** : 4 colonnes séparées par des filets de 1px (gap 1px sur fond `border`), tuiles `cream-alt` de 34px 28px, icône 20px.
- **FAQ** : section `ink`, items séparés par `hairline-on-dark`, question en `faq-question`, « + » `taupe` qui pivote de 45° à l'ouverture, réponse en `text-on-dark-muted`.
- **En-tête** : sticky, 84px, fond `header-glass` + flou 8px, filet `hairline`. Liens de nav à opacité .75.
- **Focus** : contour 2px `taupe-dark`, décalage 3px.

## Iconographie et logo

- Le seul signe graphique est la **fleur de lys Centurie** (groupe Logos). Elle sert de logo (26px à côté du logotype), de puce, d'icône de tuile, de marqueur de sur-titre (14px) et de filigrane géant (opacité .06, rotation 8°) dans le hero.
- Pas de bibliothèque d'icônes, pas d'illustrations, pas de photos sur le site. Ne pas en inventer.
- Logotype : « CENTURIE » en `wordmark`, avec « Growth » en `script-signature` dessous.

## Mise en page

- Conteneur `container-max` (1180px), gouttière `space-8` (32px), `space-5` (20px) sous 640px.
- Sections narratives en deux colonnes 1fr / 1.4fr, gap `space-15`.
- Grilles de cartes en 3 colonnes, gap `space-7`, une seule colonne (max 440 à 480px) sous 860 à 900px.
- Animations limitées à 0.2s sur couleur, opacité et translation ; tout coupé avec `prefers-reduced-motion`.

## À éviter

Arrondis généreux, ombres portées, dégradés, couleurs vives hors palette, emoji, icônes génériques, texte courant en taupe, plus d'une section sombre par page.
