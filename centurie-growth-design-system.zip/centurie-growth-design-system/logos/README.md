# Logos

- `centurie-mark-black.png` : la fleur de lys Centurie, encre avec incrustations taupe (#a9a298). Sur fonds clairs (`cream`, `cream-alt`, `white`). 748 × 640, fond transparent.
- `centurie-mark-white.png` : la même marque en blanc plein, pour les fonds `ink`.

Tailles utilisées sur le site : 26px (logo), 20px (icône de tuile), 14px (sur-titre), 11px (puce de liste), 34px (CTA final), ~780px à opacité .06 (filigrane du hero). Ne pas recolorer, étirer ni redessiner la marque.
